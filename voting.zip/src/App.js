import logo from './logo.svg';
import Vote from './voteYourLanguage/Vote';

function App() {
  return (
    <div>
     <Vote/>
    </div>

    
  );
}

export default App;
