import React,{ Component } from 'react';
import './Vote.css';
export default class Vote extends Component{
	state={
	Php:0,
	Python:0,
	Go:0,
	Java:0
	}

	php=()=>{
		this.setState({Php:this.state.Php+1})
	}
	python=()=>{
		this.setState({Python:this.state.Python+1})
	}
	go=()=>{
		this.setState({Go:this.state.Go+1})
	}
	Java=()=>{
		this.setState({Java:this.state.Java+1})
	}
	render(){
		return(
			<div className="div">
				<h1>Vote your favourite Language</h1>

				<div className="php">
					<h1>{this.state.Php}  Php<  button className="phpButton" onClick={this.php}><h1> Click Here</h1></button></h1>
				</div>
			

			<div className="python">
			<h1>{this.state.Python}  Python<button  className="pythonButton" onClick={this.python}><h1>Click Here</h1></button></h1>
		</div>
		
		<div className="go">
			<h1>{this.state.Go}  Go<button className="ogButton" onClick={this.go}><h1>Click Here</h1></button></h1>
		</div>
		
		<div className="java">
			<h1>{this.state.Java}  Java<button className="javaButton" onClick={this.Java}><h1>Click Here</h1></button></h1>
		</div>


		</div>



			
		)
	
	}
}