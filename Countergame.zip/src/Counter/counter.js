import React from 'react';
import './counter.css';
import Button from 'react-bootstrap/Button';
import { ButtonGroup } from 'react-bootstrap';
class Counter extends React.Component{
    state={
        counter: 0
    }

    
    // reSet=()=>{
    //     this.setState({counter: this.state.counter})
       
    // }


   


    InCounter=()=>{
        this.setState({counter: this.state.counter+1})
       
    }

    reset=()=>{
        this.setState({counter: this.state.counter*0})
       
    }
    Decrement=()=>{
        
        if(this.state.counter>0){
            this.setState({counter: this.state.counter-1})
        }
        else{
            window.alert('Sorry! You have reached minimun limit Zero')
        }
       
    }
    render(){
        return (
            <div className="dev" >
                <h2>Counter Game</h2>
                <h1>{this.state.counter}</h1>
                <Button variant="outline-primary" onClick={this.InCounter}>Increment</Button>{' '}
                <Button variant="outline-primary" onClick={this.reset}>Reset</Button>{' '}
                 <Button variant="danger" onClick={this.Decrement}>Decrement</Button>

              
            
             
            </div>
        )
    }
}
export default Counter;